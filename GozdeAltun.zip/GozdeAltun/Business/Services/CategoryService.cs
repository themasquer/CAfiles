﻿using AppCore.Business.Services;
using AppCore.Results.Base;
using Business.Models;

namespace Business.Services
{
    public interface ICategoryService : IService<CategoryModel> //base yapı
    {
    }

    public class CategoryService : ICategoryService //kullanacağımız somut yapı
    {
        public Result Add(CategoryModel model)
        {
            throw new NotImplementedException();
        }

        public Result Delete(int id)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IQueryable<CategoryModel> Query()
        {
            throw new NotImplementedException();
        }

        public Result Update(CategoryModel model)
        {
            throw new NotImplementedException();
        }
    }
}
