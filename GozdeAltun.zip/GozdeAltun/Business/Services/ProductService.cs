﻿using AppCore.Business.Services;
using AppCore.Results.Base;
using Business.Models;
using DataAccess.Repositories;

namespace Business.Services
{
    public interface IProductService : IService<ProductModel> //base yapı
    {
    }

    public class ProductService : IProductService //kullanacağımız somut yapı
    {
        private readonly ProductRepoBase _repo;

        public ProductService(ProductRepoBase repo)
        {
            _repo = repo;
        }

        public Result Add(ProductModel model)
        {
            throw new NotImplementedException();
        }

        public Result Delete(int id)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            _repo.Dispose();
        }

        public IQueryable<ProductModel> Query()
        {
            return _repo.Query().Select(p => new ProductModel()
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price,
                Stock = p.Stock
            });
        }

        public Result Update(ProductModel model)
        {
            throw new NotImplementedException();
        }
    }
}
