﻿using AppCore.Records;
using AppCore.Results.Base;

namespace AppCore.Business.Services
{
    public interface IService<TModel> : IDisposable where TModel : RecordBase, new()
    {
        IQueryable<TModel> Query(); // read

        Result Add(TModel model);//create

        Result Update(TModel model);//update
        
        Result Delete(int id);//delete
    }
}
