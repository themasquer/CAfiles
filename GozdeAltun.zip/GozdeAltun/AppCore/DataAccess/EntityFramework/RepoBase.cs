﻿#nullable disable

using AppCore.DataAccess.Bases;
using AppCore.Records;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Linq.Expressions;

namespace AppCore.DataAccess.EntityFramework
{
    public abstract class RepoBase <TEntity> : IRepoBase<TEntity> where TEntity : RecordBase, new()
    {
        //const string ERRORMESSAGE = "Changes not saved!";
        //const string ADDMESSAGE = "Added successfully.";
        //const string UPDATEDMESSAGE = "Updated successfully.";
        //const string DELETEMESSAGE = "Deleted successfully.";

        protected readonly DbContext _db; //ya burda newlensin ya da constructor da (readonly)

        protected RepoBase(DbContext db)//constructor injection
        {
            _db = db;
        }



        public virtual IQueryable<TEntity> Query(params Expression<Func<TEntity, object>>[] entitiesToInclude) //sorgu, read
        {
            var query = _db.Set<TEntity>().AsQueryable();

            foreach (var entityToInclude in entitiesToInclude)
            {
                query = query.Include(entityToInclude);
            }

            return query;
        }

        public virtual IQueryable<TEntity> Query(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] entitiesToInclude) //filtreleme, sorgu
        {
            var query = Query(entitiesToInclude);
            return query.Where(predicate);
        }

        public virtual void Add(TEntity entity, bool save = true)
        {
            _db.Set<TEntity>().Add(entity);
            if (save)
                Save();
        }

        public virtual void Update(TEntity entity, bool save = true)
        {
            _db.Set<TEntity>().Update(entity);
            if (save)
                Save();
        }

        public virtual void Delete(TEntity entity, bool save = true)
        {
            _db.Set<TEntity>().Remove(entity);
            if (save)
                Save();
        }

        public virtual void Delete(int id, bool save = true)
        {
           var entity = _db.Set<TEntity>().Find(id);
            Delete(entity, save);
        }

        public virtual void Delete(Expression<Func<TEntity, bool>> predicate, bool save = true)
        {
            var entities = _db.Set<TEntity>().Where(predicate).ToList();

            foreach (var entity in entities)
            {
                Delete(entity, false);
            }

            if(save) 
                Save();
        }

        public virtual int Save()//veri tabanında değişiklikleri yansıtmak için
        {
            try
            {
                return _db.SaveChanges();
            }
            catch (Exception exc)
            {

                throw exc;
            }
        }

        public void Dispose()//hafıza yönetimi için
        {
            _db?.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
