﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DataAccess.Contexts;
using DataAccess.Entities;

//Generated from Custom Template.
namespace MVC.Controllers
{
    public class Products1Controller : Controller
    {
        // TODO: Add service injections here
        private readonly IProductService _productService;

        public Products1Controller(IProductService productService)
        {
            _productService = productService;
        }

        // GET: Products1
        public IActionResult Index()
        {
            List<ProductModel> productList = new List<ProductModel>(); // TODO: Add get list service logic here
            return View(productList);
        }

        // GET: Products1/Details/5
        public IActionResult Details(int id)
        {
            ProductModel product = null; // TODO: Add get item service logic here
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // GET: Products1/Create
        public IActionResult Create()
        {
            // TODO: Add get related items service logic here to set ViewData if necessary and update null parameter in SelectList with these items
            ViewData["CategoryId"] = new SelectList(new List<SelectListItem>(), "Value", "Text");
            return View();
        }

        // POST: Products1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ProductModel product)
        {
            if (ModelState.IsValid)
            {
                // TODO: Add insert service logic here
                return RedirectToAction(nameof(Index));
            }
            // TODO: Add get related items service logic here to set ViewData if necessary and update null parameter in SelectList with these items
            ViewData["CategoryId"] = new SelectList(new List<SelectListItem>(), "Value", "Text");
            return View(product);
        }

        // GET: Products1/Edit/5
        public IActionResult Edit(int id)
        {
            ProductModel product = null; // TODO: Add get item service logic here
            if (product == null)
            {
                return NotFound();
            }
            // TODO: Add get related items service logic here to set ViewData if necessary and update null parameter in SelectList with these items
            ViewData["CategoryId"] = new SelectList(new List<SelectListItem>(), "Value", "Text");
            return View(product);
        }

        // POST: Products1/Edit
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(ProductModel product)
        {
            if (ModelState.IsValid)
            {
                // TODO: Add update service logic here
                return RedirectToAction(nameof(Index));
            }
            // TODO: Add get related items service logic here to set ViewData if necessary and update null parameter in SelectList with these items
            ViewData["CategoryId"] = new SelectList(new List<SelectListItem>(), "Value", "Text");
            return View(product);
        }

        // GET: Products1/Delete/5
        public IActionResult Delete(int id)
        {
            ProductModel product = null; // TODO: Add get item service logic here
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: Products1/Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // TODO: Add delete service logic here
            return RedirectToAction(nameof(Index));
        }
	}
}
