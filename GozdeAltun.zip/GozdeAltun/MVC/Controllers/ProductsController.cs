﻿using Business.Services;
using Microsoft.AspNetCore.Mvc;

namespace MVC.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        public IActionResult Index()//listeleme
        {
            return View();
        }
        public PartialViewResult HeaderPartial()
        {
            return PartialView();
        }

        public PartialViewResult SliderPartial()
        {
            return PartialView();
        }
    }
}
