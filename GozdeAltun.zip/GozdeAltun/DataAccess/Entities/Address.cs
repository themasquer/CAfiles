﻿#nullable disable

using AppCore.Records;

namespace DataAccess.Entities
{
    public class Address : RecordBase
    {
        public string AddressTitle { get; set; }
        public string Addres { get; set; }
        public string The { get; set; }
        public string District { get; set; }
        public string Neighbourhood { get; set; }
        public string PostCode { get; set; }
    }
}
