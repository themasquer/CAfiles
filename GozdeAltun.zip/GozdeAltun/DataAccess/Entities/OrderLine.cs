﻿#nullable disable

using AppCore.Records;

namespace DataAccess.Entities
{
    public class OrderLine : RecordBase
    {
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }
        public int Stock { get; set; }

        public int? OrderId { get; set; }
        public Order Orders { get; set; }

        public int? ProductId { get; set; }
        public Product Products  { get; set; }
    }
}
