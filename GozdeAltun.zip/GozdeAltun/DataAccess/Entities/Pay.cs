﻿#nullable disable

using AppCore.Records;

namespace DataAccess.Entities
{
    public class Pay : RecordBase
    {
        public string UserName { get; set; }
        public string CartNumber { get; set; }
        public string SecurityNumber { get; set; }
        public string CardHasName { get; set; }

        public int AddressId { get; set; }
        public Address Addres { get; set; }
    }
}
