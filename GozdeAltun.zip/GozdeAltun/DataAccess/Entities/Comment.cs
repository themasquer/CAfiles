﻿#nullable disable

using AppCore.Records;

namespace DataAccess.Entities
{
    public class Comment : RecordBase
    {
        public string CommentUser { get; set; }
        public DateTime CommentDate { get; set; }
        public string CommentContent { get; set; }
        public bool CommentState { get; set; }

        public int ProductId { get; set; }
        public Product Products { get; set; }
    }
}
