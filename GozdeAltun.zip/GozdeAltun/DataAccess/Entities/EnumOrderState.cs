﻿using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entities
{
    public enum EnumOrderState
    {
        [Display(Name = "Onay Bekleniyor!")]
        Bekleniyor,
        [Display(Name = "Tamamlandı!")]
        Tamamlandı,
        [Display(Name = "Paketlendi!")]
        Paketlendi,
        [Display(Name = "Kargolandı!")]
        Kargolandı,

    }
}
