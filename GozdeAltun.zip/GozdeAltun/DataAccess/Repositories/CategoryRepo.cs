﻿using AppCore.DataAccess.EntityFramework;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public abstract class CategoryRepoBase : RepoBase<Category> //ara yapı(bağımlılıkları yönetebilmek için)
    {
        protected CategoryRepoBase(DbContext db) : base(db)
        {
        }
    }

    public class CategoryRepo : CategoryRepoBase //esas kullnacağımız (objelere alıp kullanacağız)
    {
        public CategoryRepo(DbContext db) : base(db)
        {
        }
    }
}
