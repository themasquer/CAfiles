﻿using AppCore.DataAccess.EntityFramework;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public abstract class ProductRepoBase : RepoBase<Product>//ara yapı(bağımlılıkları yönetebilmek için) 
    {
        protected ProductRepoBase(DbContext db) : base(db)
        {
        }
    }

    public class ProductRepo : ProductRepoBase //esas kullnacağımız (objelere alıp kullanacağız)
    {
        public ProductRepo(DbContext db) : base(db)
        {
        }
    }
}
