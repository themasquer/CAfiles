﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace DataAccess.Contexts
{
    public class DbFactory : IDesignTimeDbContextFactory<ETicaretContext>
    //scaffolding işlemleri için(ETicaretContext objesini oluşturup kullanılmasını sağlar)
    {
        public ETicaretContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ETicaretContext>();
            optionsBuilder.UseSqlServer("server=(localdb)\\mssqllocaldb;database=GozdeAltunDB;trusted_connection=true;trustservercertificate=true;multipleactiveresultsets=true;");
            return new ETicaretContext(optionsBuilder.Options);
        }
    }
}
