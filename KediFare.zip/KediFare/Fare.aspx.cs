﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Fare : System.Web.UI.Page
{
    private const string blackurl = "./images/black.JPG";
    private const string whiteurl = "./images/white.JPG";
    private const string ratnonselectedurl = "./images/rat_nonSelected.JPG";
    private const string catnonselectedurl = "./images/cat_nonSelected.JPG";
    private const string ratselectedurl = "./images/rat_selected.jpg";
    private const string catselectedurl = "./images/cat_selected.jpg";
    private static string turn; // Sıra kimde: "rat" = farede, "cat" = kedide.
    private static int ratMoveNumber; // Oyun boyunca farenin toplam hareket sayısı.
    private static int catMoveNumber; // Oyun boyunca kedinin toplam hareket sayısı.
    private static bool ratSelected; // Farenin seçilip seçilmediği.
    private static bool catSelected; // Kedinin seçilip seçilmediği.
    private static string ratOldPosition; // Farenin seçildiği andaki pozisyonu.
    private static string ratNewPosition; // Farenin gideceği yerin pozisyonu. 
    private static string catOldPosition; // Kedinin seçildiği andaki pozisyonu.
    private static string catNewPosition; // Kedinin gideceği yerin pozisyonu. 
    private static string catName; // Seçilen kedinin adı: "cat1", "cat2", "cat3" veya "cat4" olabilir.
    static int oyunID;
    SQLdatabase sqldb = new SQLdatabase("kedifare");
    string sql = "";
    int result;
    DataSet ds;
    static bool oyunBasladi;
    static string yeniOyun;
    static int i;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            bool sayfayiYukle = false;
            timer.Interval = Convert.ToInt32(ConfigurationManager.AppSettings["timerinterval"]);
            yeniOyun = "";
            if (Request.QueryString.Count == 2)
            {
                if (Request.QueryString["i"] != null && Request.QueryString["y"] != null)
                {
                    if (Request.QueryString["y"].Equals("1") || Request.QueryString["y"].Equals("0"))
                    {
                        int oyuncuID;
                        bool isInteger = int.TryParse(Request.QueryString["i"], out oyuncuID);
                        if (isInteger)
                        {
                            yeniOyun = Request.QueryString["y"];
                            if (yeniOyun.Equals("1"))
                            {
                                sql = "select ID, 0 from KediFareOyun where fare_ID = " + oyuncuID + " and kedi_ID is null and durum = 'Oyun açıldı.'";
                                sayfayiYukle = true;
                            }
                            else
                            {
                                sql = "select ID, (select ISNULL(MAX(fare_ID), 0) + 1 from KediFareOyun) from KediFareOyun where kedi_ID = " + oyuncuID;
                            }
                            ds = sqldb.SQL_SelectAdapter(sql, out result);
                            if (result != -1)
                            {
                                if (ds != null)
                                {
                                    if (ds.Tables.Count > 0)
                                    {
                                        if (ds.Tables[0].Rows.Count > 0)
                                        {
                                            oyunID = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                                            if (yeniOyun.Equals("0"))
                                            {
                                                oyuncuID = Convert.ToInt32(ds.Tables[0].Rows[0][1]);
                                                sql = "update KediFareOyun set fare_ID = " + oyuncuID + ", durum = 'Oyun başladı.' where ID = " + oyunID;
                                                result = sqldb.SQL_InsertUpdateDelete(sql);
                                                if (result != -1)
                                                    sayfayiYukle = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (sayfayiYukle)
            {
                timer.Enabled = true;
                i = 1;
                oyunBasladi = false;
                if (yeniOyun.Equals("1"))
                {
                    yukle("formload");
                }
                else
                {
                    yukle("buttonclick");
                }
            }
            else
            {
                Response.Redirect("YeniOyun.aspx");
            }
        }
    }

    private void yukle(string operation)
    {
        if (operation.Equals("formload"))
        {
            l_durum.Text = "Diğer oyuncunun<br />";
            l_durum.Text += "oyuna girmesi bekleniyor...";
        }
        else if (operation.Equals("buttonclick"))
        {
            drawBoard();
            ratMoveNumber = -1;
            catMoveNumber = -4;
            ratOldPosition = "";
            ratNewPosition = "";
            catOldPosition = "";
            catNewPosition = "";
            moveRat("14");
            moveCat("81", "cat1");
            moveCat("83", "cat2");
            moveCat("85", "cat3");
            moveCat("87", "cat4");
            tb_fareHamleSayisi.Text = "0";
            tb_kediHamleSayisi.Text = "0";
            l_durum.Text = "Oyun başladı, sıra farede.";
        }
        else if (operation.Equals("ratwins") || operation.Equals("catwins"))
        {
            string piece = "";
            if (operation.Equals("ratwins"))
                piece = "fare";
            else
                piece = "kedi";
            foreach (Control control in Panel1.Controls)
            {
                if (control is ImageButton)
                {
                    (control as ImageButton).Enabled = false;
                }
            }
            l_durum.Text = "Oyunu " + piece + " kazandı.<br />";
            l_durum.Text += "Yeni oyuna başlamak için<br />";
            l_durum.Text += "\"Yeni Oyun\" butonuna tıklayın...";
        }
    }

    private void drawBoard() // Satranç tahtasını çizer.
    {
        bool black = false;
        int i = 0;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                i++;
                if (black)
                {
                    (control as ImageButton).ImageUrl = blackurl;
                    (control as ImageButton).Enabled = false; // Oyun sadece beyazlar üzerinde oynanabilir.
                }
                else
                {
                    (control as ImageButton).ImageUrl = whiteurl;
                    (control as ImageButton).Enabled = true; // Oyun sadece beyazlar üzerinde oynanabilir.
                }
                (control as ImageButton).CommandName = ""; // "Satranç tahtasındaki taş" + "_" + "hareket sayısı" (Örnek: "cat1_1", "cat4_13", "rat_5", "rat_18"). 
                if (i % 8 != 0)
                    black = !black;
            }
        }
    }

    protected void button_Click(object sender, ImageClickEventArgs e) // Fare veya kedilerden biri hareket ettirildiğinde yapılacak işlemler.
    {
        ImageButton button = sender as ImageButton;
        string position = button.CommandArgument.ToString();
        if (turn.Equals("rat"))
        {
            if (ratSelected == false)
            {
                selectRat(position);
                timer.Enabled = false;
            }
            else
            {
                if (ratCanMove(position))
                {
                    moveRat(position);
                    sql = "update KediFareOyun set farepozisyonu = 'rat;" + ratOldPosition + ";" + ratNewPosition + "' where ID = " + oyunID + " and durum = 'Oyun başladı.'";
                    result = sqldb.SQL_InsertUpdateDelete(sql);
                    if (result != -1)
                    {
                        tb_fareHamleSayisi.Text = ratMoveNumber.ToString();
                        if (checkRatWins())
                        {
                            yukle("ratwins");
                            timer.Enabled = false;
                            b_yeniOyun.Visible = true;
                            sql = "update KediFareOyun set farehamlesayisi = " + tb_fareHamleSayisi.Text + ", kedihamlesayisi = " + tb_kediHamleSayisi.Text + ", durum = 'Fare kazandı.' where ID = " + oyunID + " and durum = 'Oyun başladı.'";
                            result = sqldb.SQL_InsertUpdateDelete(sql);
                            if (result == -1)
                                l_durum.Text = "Oyun durumu güncellenirken hata meydana geldi!";
                        }
                        else
                        {
                            timer.Enabled = true;
                            i = 1;
                        }
                    }
                    else
                    {
                        l_durum.Text = "Farenin hamlesi sırasında hata meydana geldi!";
                        timer.Enabled = false;
                    }
                }
                else
                {
                    l_durum.Text = "Yanlış hareket!";
                    timer.Enabled = false;
                }
            }
        }
    }

    protected void b_yeniOyun_Click(object sender, EventArgs e)
    {
        timer.Enabled = false;
        Response.Redirect("YeniOyun.aspx");
    }

    private void moveRat(string position) // Fareyi belirtilen pozisyona götürür.
    {
        ratNewPosition = position;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(ratNewPosition) && (control as ImageButton).CommandName.Equals(""))
                {
                    if (!ratOldPosition.Equals(ratNewPosition))
                    {
                        (control as ImageButton).ImageUrl = ratnonselectedurl;
                        ratMoveNumber++;
                        (control as ImageButton).CommandName = "rat" + "_" + ratMoveNumber;
                        turn = "cat";
                        l_durum.Text = "Sıra kedide.";
                    }
                    break;
                }
            }
        }
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(ratOldPosition) && (control as ImageButton).CommandName.Contains("rat"))
                {
                    if (!ratOldPosition.Equals(ratNewPosition))
                    {
                        (control as ImageButton).ImageUrl = whiteurl;
                        (control as ImageButton).CommandName = "";
                    }
                    else
                    {
                        (control as ImageButton).ImageUrl = ratnonselectedurl;
                        (control as ImageButton).CommandName = "rat" + "_" + ratMoveNumber;
                        turn = "rat";
                    }
                    break;
                }
            }
        }
        ratSelected = false;
    }

    private void moveCat(string position, string cat) // Seçilen kediyi belirtilen pozisyona götürür.
    {
        catNewPosition = position;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(catNewPosition) && (control as ImageButton).CommandName.Equals(""))
                {
                    if (!catOldPosition.Equals(catNewPosition))
                    {
                        (control as ImageButton).ImageUrl = catnonselectedurl;
                        catMoveNumber++;
                        (control as ImageButton).CommandName = cat + "_" + catMoveNumber;
                        turn = "rat";
                        l_durum.Text = "Sıra farede.";
                    }
                    break;
                }
            }
        }
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(catOldPosition) && (control as ImageButton).CommandName.Contains(cat))
                {
                    if (!catOldPosition.Equals(catNewPosition))
                    {
                        (control as ImageButton).ImageUrl = whiteurl;
                        (control as ImageButton).CommandName = "";
                    }
                    else
                    {
                        (control as ImageButton).ImageUrl = catnonselectedurl;
                        (control as ImageButton).CommandName = cat + "_" + catMoveNumber;
                        turn = "cat";
                    }
                    break;
                }
            }
        }
        catSelected = false;
    }

    private void selectRat(string position) // Fareyi seçer.
    {
        ratOldPosition = position;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(ratOldPosition) && (control as ImageButton).CommandName.Contains("rat"))
                {
                    ratSelected = true;
                    (control as ImageButton).ImageUrl = ratselectedurl;
                    break;
                }
            }
        }
    }

    private bool ratCanMove(string position) // Fare seçilen pozisyona hareket edebilir mi kontrol eder (newX ve newY yeni pozisyon, oldX ve oldY eski pozisyon).
    {
        bool result = false;
        bool quit = false;
        int newY = Convert.ToInt32(position.Substring(0, 1));
        int newX = Convert.ToInt32(position.Substring(1, 1));
        int oldY = Convert.ToInt32(ratOldPosition.Substring(0, 1));
        int oldX = Convert.ToInt32(ratOldPosition.Substring(1, 1));
        if (newX == oldX && newY == oldY)
        {
            result = true;
        }
        else
        {
            foreach (Control control in Panel1.Controls)
            {
                if (control is ImageButton)
                {
                    if ((control as ImageButton).CommandArgument.Equals(position))
                    {
                        if ((control as ImageButton).CommandName.Contains("cat"))
                        {
                            quit = true;
                        }
                        break;
                    }
                }
            }
            if (quit == false)
            {
                if ((newY == oldY + 1) || (newY == oldY - 1))
                {
                    if ((newX == oldX + 1) || (newX == oldX - 1))
                    {
                        result = true;
                    }
                }
            }
        }
        return result;
    }

    private bool checkRatWins()
    {
        bool ratWins = false;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.ToString().Substring(0, 1).Equals("8") && (control as ImageButton).CommandName.Contains("rat"))
                {
                    ratWins = true;
                    break;
                }
            }
        }
        return ratWins;
    }

    private void selectCat(string position, string cat) // Kediyi seçer.
    {
        catOldPosition = position;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandArgument.Equals(catOldPosition) && (control as ImageButton).CommandName.Contains(cat))
                {
                    catName = (control as ImageButton).CommandName.Split('_')[0];
                    catSelected = true;
                    (control as ImageButton).ImageUrl = catselectedurl;
                    break;
                }
            }
        }
    }

    private bool catCanMove(string position) // Kedi seçilen pozisyona hareket edebilir mi kontrol eder (newX ve newY yeni pozisyon, oldX ve oldY eski pozisyon).
    {
        bool result = false;
        bool quit = false;
        int newY = Convert.ToInt32(position.Substring(0, 1));
        int newX = Convert.ToInt32(position.Substring(1, 1));
        int oldY = Convert.ToInt32(catOldPosition.Substring(0, 1));
        int oldX = Convert.ToInt32(catOldPosition.Substring(1, 1));
        if (newX == oldX && newY == oldY)
        {
            result = true;
        }
        else
        {
            foreach (Control control in Panel1.Controls)
            {
                if (control is ImageButton)
                {
                    if ((control as ImageButton).CommandArgument.Equals(position))
                    {
                        if ((control as ImageButton).CommandName.Contains("rat") || (control as ImageButton).CommandName.Contains("cat"))
                        {
                            quit = true;
                        }
                        break;
                    }
                }
            }
            if (quit == false)
            {
                if (newY == oldY - 1)
                {
                    if ((newX == oldX + 1) || (newX == oldX - 1))
                    {
                        result = true;
                    }
                }
            }
        }
        return result;
    }

    private bool checkCatWins()
    {
        bool catWins = false;
        string ratPosition = "";
        int ratYposition = 0;
        int ratXposition = 0;
        List<string> catPositions = new List<string>();
        bool firstCatInPlace = false;
        bool secondCatInPlace = false;
        bool thirdCatInPlace = false;
        bool fourthCatInPlace = false;
        foreach (Control control in Panel1.Controls)
        {
            if (control is ImageButton)
            {
                if ((control as ImageButton).CommandName.Contains("cat1"))
                    catPositions.Add((control as ImageButton).CommandArgument.ToString());
                else if ((control as ImageButton).CommandName.Contains("cat2"))
                    catPositions.Add((control as ImageButton).CommandArgument.ToString());
                else if ((control as ImageButton).CommandName.Contains("cat3"))
                    catPositions.Add((control as ImageButton).CommandArgument.ToString());
                else if ((control as ImageButton).CommandName.Contains("cat4"))
                    catPositions.Add((control as ImageButton).CommandArgument.ToString());
                else if ((control as ImageButton).CommandName.Contains("rat"))
                    ratPosition = (control as ImageButton).CommandArgument.ToString();
                if (catPositions.Count == 4 && !ratPosition.Equals(""))
                {
                    break;
                }
            }
        }
        ratYposition = Convert.ToInt32(ratPosition.Substring(0, 1));
        ratXposition = Convert.ToInt32(ratPosition.Substring(1, 1));
        if (ratYposition == 1 && ratXposition == 8)
        {
            foreach (string catPosition in catPositions)
            {
                if (((ratYposition + 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                {
                    catWins = true;
                    break;
                }
            }
        }
        else if (ratYposition == 1)
        {
            foreach (string catPosition in catPositions)
            {
                if (((ratYposition + 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                    firstCatInPlace = true;
                if (((ratYposition + 1).ToString() + (ratXposition + 1).ToString()).Equals(catPosition))
                    secondCatInPlace = true;
                if (firstCatInPlace && secondCatInPlace)
                {
                    catWins = true;
                    break;
                }
            }
        }
        else if (ratXposition == 1)
        {
            foreach (string catPosition in catPositions)
            {
                if (((ratYposition - 1).ToString() + (ratXposition + 1).ToString()).Equals(catPosition))
                    firstCatInPlace = true;
                if (((ratYposition + 1).ToString() + (ratXposition + 1).ToString()).Equals(catPosition))
                    secondCatInPlace = true;
                if (firstCatInPlace && secondCatInPlace)
                {
                    catWins = true;
                    break;
                }
            }
        }
        else if (ratXposition == 8)
        {
            foreach (string catPosition in catPositions)
            {
                if (((ratYposition - 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                    firstCatInPlace = true;
                if (((ratYposition + 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                    secondCatInPlace = true;
                if (firstCatInPlace && secondCatInPlace)
                {
                    catWins = true;
                    break;
                }
            }
        }
        else
        {
            foreach (string catPosition in catPositions)
            {
                if (((ratYposition - 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                    firstCatInPlace = true;
                if (((ratYposition - 1).ToString() + (ratXposition + 1).ToString()).Equals(catPosition))
                    secondCatInPlace = true;
                if (((ratYposition + 1).ToString() + (ratXposition + 1).ToString()).Equals(catPosition))
                    thirdCatInPlace = true;
                if (((ratYposition + 1).ToString() + (ratXposition - 1).ToString()).Equals(catPosition))
                    fourthCatInPlace = true;
                if (firstCatInPlace && secondCatInPlace && thirdCatInPlace && fourthCatInPlace)
                {
                    catWins = true;
                    break;
                }
            }
        }
        return catWins;
    }

    protected void b81_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b83_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b85_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b87_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b72_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b74_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b76_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b78_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b61_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b63_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b65_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b67_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b52_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b54_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b56_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b58_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b41_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b43_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b45_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b47_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b32_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b34_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b36_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b38_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b21_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b23_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b25_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b27_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b12_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b14_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b16_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void b18_Click(object sender, ImageClickEventArgs e)
    {
        button_Click(sender, e);
    }

    protected void timer_Tick(object sender, EventArgs e)
    {
        if (i > Convert.ToInt32(ConfigurationManager.AppSettings["timeout"]))
        {
            timer.Enabled = false;
            b_yeniOyun.Visible = true;
            l_durum.Text = "Oyun zaman aşımına uğradı.<br />Yeni oyuna başlayın.";
        }
        else
        {
            sql = "select ISNULL(kedipozisyonu, '') from KediFareOyun where ID = " + oyunID + " and durum in ('Oyun başladı.', 'Fare kazandı.', 'Kedi kazandı.')";
            ds = sqldb.SQL_SelectAdapter(sql, out result);
            if (result == -1)
            {
                timer.Enabled = false;
                l_durum.Text = "Oyun sorgulanırken hata meydana geldi!";
            }
            else
            {
                i++;
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            if (!oyunBasladi)
                            {
                                yukle("buttonclick");
                                timer.Enabled = false;
                                oyunBasladi = true;
                            }
                            else
                            {
                                if (!ds.Tables[0].Rows[0][0].ToString().Equals(""))
                                {
                                    catOldPosition = ds.Tables[0].Rows[0][0].ToString().Split(';')[1];
                                    moveCat(ds.Tables[0].Rows[0][0].ToString().Split(';')[2], ds.Tables[0].Rows[0][0].ToString().Split(';')[0]);
                                    tb_kediHamleSayisi.Text = catMoveNumber.ToString();
                                    if (checkCatWins())
                                    {
                                        yukle("catwins");
                                        timer.Enabled = false;
                                        b_yeniOyun.Visible = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}