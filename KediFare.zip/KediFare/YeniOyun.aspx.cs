﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class YeniOyun : System.Web.UI.Page
{
    static string oyuncu = "";
    static int oyuncuID = 0;
    string yeniOyun = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            b_oyunaBasla.Attributes.Add("data-clipboard-target", ".clipboard_label");
        }
    }

    protected void b_yeniOyun_Click(object sender, EventArgs e)
    {
        SQLdatabase sqldb = new SQLdatabase("kedifare");
        string selectSQL = "";
        int result;
        string url = "";
        yeniOyun = "0";
        if (rbl_yeniOyun.SelectedValue.Equals("Fare"))
        {
            selectSQL = "select ISNULL(MAX(fare_ID), 0) + 1 from KediFareOyun";
            oyuncu = "f";
        }
        else
        {
            selectSQL = "select ISNULL(MAX(kedi_ID), 0) + 1 from KediFareOyun";
            oyuncu = "k";
        }
        //oyuncuID = Convert.ToInt32(sqldb.SQL_SelectScalar(selectSQL, out result));
        var obj = sqldb.SQL_SelectScalarTest(selectSQL, out result);
        if (result != -1)
        {
            oyuncuID = Convert.ToInt32(obj);
            if (oyuncu.Equals("f"))
                url = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/Kedi.aspx?i=" + oyuncuID + "&y=" + yeniOyun;
            else
                url = Request.Url.Scheme + "://" + Request.Url.Authority + Request.ApplicationPath.TrimEnd('/') + "/Fare.aspx?i=" + oyuncuID + "&y=" + yeniOyun;
            l_yeniOyun.Text = url;
            b_oyunaBasla.Visible = true;
        }
        else
        {
            l_yeniOyun.Text = "Oyunlar sorgulanırken hata meydana geldi! " + obj;
        }
        sqldb.Destroy();
    }

    protected void b_oyunaBasla_Click(object sender, EventArgs e)
    {
        SQLdatabase sqldb = new SQLdatabase("kedifare");
        string insertSQL = "";
        int result;
        yeniOyun = "1";
        if (oyuncu.Equals("f"))
            insertSQL = "insert into KediFareOyun values (@ID, null, null, null, null, null, 'Oyun açıldı.')";
        else
            insertSQL = "insert into KediFareOyun values (null, @ID, null, null, null, null, 'Oyun açıldı.')";
        insertSQL = insertSQL.Replace("@ID", oyuncuID.ToString());
        result = sqldb.SQL_InsertUpdateDelete(insertSQL);
        sqldb.Destroy();
        if (result != -1)
        {
            if (oyuncu.Equals("f"))
                Response.Redirect("Fare.aspx?i=" + oyuncuID + "&y=" + yeniOyun);
            else
                Response.Redirect("Kedi.aspx?i=" + oyuncuID + "&y=" + yeniOyun);
        }
        else
        {
            l_yeniOyun.Text = "Oyun oluşturulurken hata meydana geldi!";
        }
    }

    protected void rbl_yeniOyun_SelectedIndexChanged(object sender, EventArgs e)
    {
        l_yeniOyun.Text = "";
        b_oyunaBasla.Visible = false;
    }

    protected void b_baslaOyuna_Click(object sender, EventArgs e)
    {
        Response.Redirect("KediFare.aspx");
    }
}